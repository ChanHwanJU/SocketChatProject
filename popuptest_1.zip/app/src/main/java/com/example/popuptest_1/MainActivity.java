package com.example.popuptest_1;

import androidx.appcompat.app.AppCompatActivity;

import android.app.*;
import android.content.*;
import android.os.Bundle;
import android.view.*;
import android.widget.*;

public class MainActivity extends AppCompatActivity {

    Button btn_dialog;
    TextView tv_result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_dialog = (Button)findViewById(R.id.btn_dialog);
        tv_result =  (TextView)findViewById(R.id.tv_result);

        btn_dialog.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                AlertDialog.Builder ad = new AlertDialog.Builder(MainActivity.this);
                ad.setIcon(R.mipmap.ic_launcher); //dialog창에서 필수적으로 해줘야되는 이미지셋
                ad.setTitle("테스트");
                ad.setMessage("테스트 메세지를 입력해주세요.");

                final EditText et = new EditText(MainActivity.this); //option
                ad.setView(et);

                ad.setPositiveButton("확인", new DialogInterface.OnClickListener() { //확인 버튼을 눌렀을때 실행할 동작

                    public void onClick(DialogInterface dialog, int which) {
                        String result = et.getText().toString(); //EditText에 사용자가 적은 값을 가져오기
                        tv_result.setText(result); //다이얼로그 EditText에 입력 시켜둔거 가져와라
                        dialog.dismiss();//다이얼로그창 닫기
                    }
                });

                ad.setNegativeButton("취소", new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                ad.show();
            }

        });
    }
}